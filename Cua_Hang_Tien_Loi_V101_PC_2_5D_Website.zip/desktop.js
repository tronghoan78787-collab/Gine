/* V101: PC command dashboard and keyboard/mouse controls. Gameplay state unchanged. */
(()=>{'use strict';
const g=window.ChibiV100;
if(!g) return;
const $=id=>document.getElementById(id),fmt=n=>new Intl.NumberFormat('vi-VN').format(Math.round(Number(n)||0));
const items=[['drink','🥤','Đồ uống'],['snack','🍪','Bánh kẹo'],['milk','🥛','Sữa'],['fruit','🍎','Trái cây'],['noodle','🍜','Mì gói'],['frozen','🧊','Đông lạnh']];
let lastJSON='';
const $rows=$('pcStockRows');
if($rows) $rows.innerHTML=items.map(p=>`<div class="desk-pill"><span>${p[1]} ${p[2]}</span><b id="pcQty-${p[0]}">—</b></div><div class="desk-meter"><i id="pcMeter-${p[0]}"></i></div>`).join('');
const n=(id,value)=>{const el=$(id);if(el&&el.textContent!==String(value))el.textContent=value};
function update(){const s=g.getState?.();if(!s)return;
 const key=JSON.stringify([s.cash,s.opened,s.stats?.dayRevenue,s.stats?.served,s.stats?.dayServed,s.rep,s.staff,s.level,s.day,s.storeGrade,s.quality,s.shelves,s.energy,s.minute]);
 if(key===lastJSON)return;lastJSON=key;
 n('pcRevenue',fmt(s.stats?.dayRevenue)+'đ');n('pcServed',fmt(s.stats?.dayServed));n('pcMoney',fmt(s.cash)+'đ');n('pcReputation',Math.round(s.rep)+'%');n('pcStaff',s.staff+' người');n('pcUpgrade','Cấp '+s.storeGrade);
 n('pcDay','NGÀY '+s.day);n('pcOpen',s.opened?'ĐANG ĐÓN KHÁCH':'ĐÃ ĐÓNG CỬA');n('pcQuality',s.quality==='high'?'HD':s.quality==='eco'?'TIẾT KIỆM':'CÂN BẰNG');
 const cap=20+s.storeGrade*6;
 for(const [id] of items){const slot=s.shelves?.[id];if(!slot)continue;let front=Math.max(0,slot.front),warehouse=Math.max(0,slot.warehouse);n('pcQty-'+id,front+' / '+warehouse);const meter=$('pcMeter-'+id);if(meter)meter.style.width=Math.min(100,front/cap*100)+'%';}
}
function clickAction(cmd){if(cmd==='fullscreen'){toggleFullScreen();return}if(cmd==='zoomIn'){window.Store2D5?.zoom?.(.12);return}if(cmd==='zoomOut'){window.Store2D5?.zoom?.(-.12);return}if(cmd.startsWith('panel:'))g.openPanel(cmd.slice(6));else g.action(cmd)}
document.addEventListener('click',e=>{const el=e.target.closest('[data-pc-action]');if(!el)return;clickAction(el.dataset.pcAction)});

document.addEventListener('keydown',e=>{
 if(e.ctrlKey||e.metaKey||e.altKey||e.target?.closest('input,textarea,select,[contenteditable]'))return;
 if(!document.getElementById('welcome')?.hidden)return;
 const shortcuts={Digit1:'overview',Digit2:'staff',Digit3:'orders',Digit4:'stock',Digit5:'products',Digit6:'reports',Digit7:'upgrade',Digit8:'decor',KeyR:'stock',KeyI:'orders',KeyM:'marketing'};
 if(shortcuts[e.code]){e.preventDefault();g.openPanel(shortcuts[e.code]);return}
 if(e.code==='Space'){e.preventDefault();g.action('toggle');return}
 if(e.code==='KeyF'){e.preventDefault();toggleFullScreen();return}
 if(['Equal','NumpadAdd'].includes(e.code)){e.preventDefault();window.Store2D5?.zoom?.(.12);return}
 if(['Minus','NumpadSubtract'].includes(e.code)){e.preventDefault();window.Store2D5?.zoom?.(-.12);return}
 if(e.code==='ArrowLeft'||e.code==='ArrowRight'){e.preventDefault();window.Store2D5?.pan?.(e.code==='ArrowLeft'?70:-70);return}
});
function toggleFullScreen(){const root=$('app');if(!document.fullscreenElement)root.requestFullscreen?.().catch(()=>{});else document.exitFullscreen?.().catch(()=>{})}
window.PC101={update,toggleFullScreen};
setInterval(update,800);update();
})();
