# Cửa Hàng Tiện Lợi V101 — PC Website 2.5D

**Loại trò chơi:** Game quản lý cửa hàng tiện lợi, vẽ trực tiếp bằng Canvas 2.5D, không yêu cầu WebGL. Giữ hệ thống kinh doanh / nhập kho / nhân viên / nâng cấp từ V100.

## Chơi miễn phí trên PC

**Lựa chọn 1 — một tệp:** Tải `v101-pc.html` (tệp riêng đính kèm ở ngoài ZIP) lên thư mục gốc của kho GitHub Pages Gane. Sau khi GitHub xuất bản, mở `https://tronghoan78787-collab.github.io/Gane/v101-pc.html`. Tài nguyên đã nhúng trong file; không cần cài thư viện. Dữ liệu lưu ở trình duyệt đang dùng.

**Lựa chọn 2 — website hoàn chỉnh:** Đưa toàn bộ nội dung gói ZIP vào một thư mục `pc/` của repo rồi mở `https://tronghoan78787-collab.github.io/Gane/pc/`. Phải giữ đường dẫn `index.html`, `desktop.css`, `desktop.js`, `style.css`, `game.js`, `scene25.js`, `assets/`, `sw.js`, `manifest.webmanifest`. GitHub không tự giải nén ZIP. Trang cần HTTPS để đăng ký offline cache service worker và lần đầu vẫn cần mạng. Trong môi trường thử nghiệm chưa xác nhận tính năng offline.

**Hướng dẫn điều khiển:**
- 1–8: Mở bảng quản lý tương ứng trên thanh dưới.
- Space: Mở / đóng cửa hàng.
- F: Toàn màn hình (nếu trình duyệt cho phép).
- +/- hoặc con lăn chuột: Thu phóng camera, tối đa 175%.
- Kéo ngang trong cảnh / phím mũi tên trái phải: Dịch chuyển camera.
- Esc: Đóng bảng quản lý.
- Nhập hàng tại Nhập hàng → mua kiện 12 → Bổ sung toàn bộ lên kệ → đón khách.

**Dữ liệu:** PC V101 sử dụng cùng định dạng bản lưu `cuahangtienloi:v100:save1` với V100 trên cùng domain, nhằm giữ tiến độ từ V100. Dữ liệu của V95 riêng biệt. Sao lưu qua Cài đặt → Xuất bản lưu. Các trình duyệt/thiết bị khác nhau không tự chia sẻ tiến độ.

**Kiểm thử:** Chromium dựng được cảnh, tải đủ sprite, xác nhận nhập hàng trừ tiền, mở bảng bằng phím tắt, cập nhật tồn kho, điều khiển thu phóng và giao diện 1280×768 / 1600×900. Không có lỗi JavaScript trong lần thử. Kiểm thử trên trình duyệt thật qua GitHub Pages, offline và FPS trên phần cứng người dùng vẫn chưa xác nhận.
