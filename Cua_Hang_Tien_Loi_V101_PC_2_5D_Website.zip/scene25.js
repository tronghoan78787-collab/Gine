/* Cửa Hàng Tiện Lợi V100 | original 2.5D Canvas environment. No WebGL or external dependencies. */
(() => {
'use strict';
const canvas = document.getElementById('storeCanvas');
if (!canvas) return;
const viewCtx = canvas.getContext('2d',{alpha:false});
if (!viewCtx) return;
let ctx=viewCtx;
const W=1200,H=700, sx=55,sy=24,center=600,top=112,unit=51;
const P=(u,v,z=0)=>({x:center+(u-v)*sx,y:top+(u+v)*sy-z*unit});
const colors={outline:'#537c81',cream:'#fff4ce',mint:'#70d4ac',coral:'#f2796d',plum:'#534a82',blue:'#63bcd9'};
const imgs={}; const itemPalette={drink:['#54bce3','#3383d1','#ffcc4b'],snack:['#f2ac4d','#f06f7b','#a37cdb'],milk:['#c7ecfb','#4baded','#f8ecfc'],fruit:['#f1b851','#eb6b6d','#82c886'],noodle:['#fbd56b','#e48b50','#ec776a'],frozen:['#9acbea','#95a7df','#f4e4ff']};
function asset(name,path){if(imgs[name])return imgs[name];const im=new Image();im.decoding='async';im.src=window.V100_ASSETS?.[name]||path;imgs[name]=im;return im}
for (const key of ['an','binh','linh','minh','customer_a','customer_b','customer_c'])for(const motion of ['idle','wave','work','scan'])asset('art/'+key+'_'+motion+'_happy','assets/art/'+key+'_'+motion+'_happy.png');
function poly(points,fill,stroke=null,width=1){ctx.beginPath();points.forEach((pt,i)=>i?ctx.lineTo(pt.x,pt.y):ctx.moveTo(pt.x,pt.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.lineJoin='round';ctx.stroke()}}
function path(points,color,width=2){ctx.beginPath();points.forEach((pt,i)=>i?ctx.lineTo(pt.x,pt.y):ctx.moveTo(pt.x,pt.y));ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineJoin='round';ctx.stroke()}
function round(x,y,w,h,r,fill,stroke=null){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}}
function circle(x,y,r,fill,stroke){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=2;ctx.stroke()}}
function ellipse(x,y,rx,ry,fill){ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fillStyle=fill;ctx.fill()}
function text(s,x,y,size=15,color='#365b5b',align='center',stroke=''){ctx.font=`900 ${size}px ui-rounded,-apple-system,system-ui,sans-serif`;ctx.textAlign=align;ctx.textBaseline='middle';if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=3;ctx.strokeText(s,x,y)}ctx.fillStyle=color;ctx.fillText(s,x,y)}
function box(u,v,w,d,h,z=0,topColor='#fff2ce',right='#a2c4ba',left='#e5d8b5',edge='#648c89'){
 const a=P(u,v,z+h),b=P(u+w,v,z+h),c=P(u+w,v+d,z+h),dd=P(u,v+d,z+h),e=P(u+w,v+d,z),f=P(u,v+d,z),g=P(u+w,v,z);
 poly([dd,c,e,f],left,edge,1.1);poly([b,c,e,g],right,edge,1.1);poly([a,b,c,dd],topColor,edge,1.1);
 // Thin reflected edges add the soft, hand-painted volume of a 2.5D tycoon game.
 path([a,b], '#ffffff75', Math.min(2,1+h*.38));path([a,dd],'#fff9db66',1.5);
 return {a,b,c,d:dd,e,f};
}
function wall(){
 const back=P(0,0),east=P(9,0),west=P(0,9);
 const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#ace6f1');bg.addColorStop(.55,'#ccefdc');bg.addColorStop(1,'#e9f6d5');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
 // Outside neighbourhood: soft dawn skyline and street-side trees.
 const bloom=ctx.createRadialGradient(660,40,20,660,40,610);bloom.addColorStop(0,'#fff8d58c');bloom.addColorStop(.55,'#fcf4df11');bloom.addColorStop(1,'#ffffff00');ctx.fillStyle=bloom;ctx.fillRect(0,0,W,430);
  for(let i=0;i<18;i++){const x=i*73-20,hh=65+(i*49%71);ctx.fillStyle=i%3===0?'#a0c6bf':'#beddd4';ctx.fillRect(x,184-hh,50,hh);ctx.fillStyle='#d5e9dd';for(let q=0;q<3;q++)ctx.fillRect(x+7+q*12,195-hh,6,14)}
 ellipse(190,220,125,18,'#80c9a777');ellipse(1020,220,153,22,'#80c9a777');
 for(let i=0;i<12;i++){const x=40+i*105,y=194+(i%3)*8;ctx.fillStyle='#69b58c';circle(x,y-24,17+(i%3)*7,'#80c69faa');circle(x+15,y-30,13,'#a4dab0');path([{x,y:y-15},{x,y:y+13}],'#998a65',4)}
 
 // wall panels rise 160 px above diamond
 poly([P(0,9),P(0,0),{x:back.x,y:back.y-185},{x:west.x,y:west.y-185}],'#ffe7b9','#c8a47f',3);
 poly([P(0,0),P(9,0),{x:east.x,y:east.y-185},{x:back.x,y:back.y-185}],'#f3d6ab','#c8a47f',3);
 // Wall horizontal trim
 path([{x:west.x,y:west.y-174},{x:back.x,y:back.y-174},{x:east.x,y:east.y-174}],'#fff8e5',9);
 path([P(0,9),P(0,0),P(9,0)],'#b88c72',7);
 // left wall windows - large aqua glass
 for(let i=0;i<3;i++){
 const b1=P(0,2.7+i*1.7),b2=P(0,3.95+i*1.7);
 poly([{x:b1.x,y:b1.y-174},{x:b2.x,y:b2.y-174},{x:b2.x,y:b2.y-40},{x:b1.x,y:b1.y-40}],'#83c5c3','#fff2cf',5);
 path([{x:b1.x,y:b1.y-85},{x:b2.x,y:b2.y-85}],'#e5ffffb7',3);
 path([{x:b1.x-6,y:b1.y-140},{x:b2.x-6,y:b2.y-140}],'#ffffff50',3);
 }
 // warm indoor wall panel and red banner
 const sign=P(3.8,0);round(sign.x-120,sign.y-184,230,57,17,'#e95b55','#fff0d0');
 text('TIỆM CHIBI',sign.x-5,sign.y-164,24,'#fffdf5','center','#cc464c');
 text('Tươi ngon mỗi ngày!',sign.x-5,sign.y-142,13,'#fff6db');
 // posters on right wall
 for(let i=0;i<3;i++){const p=P(5.5+i*1.2,0);round(p.x-31,p.y-152,62,86,10,['#fc9695','#ffe08c','#92d7b8'][i],'#fff9dd');text(['SIÊU','ƯU','ĐÃI'][i],p.x,p.y-125,13,'#9a4458');text(['🍓','🥤','🍪'][i],p.x,p.y-90,26)}
 // hanging lights
 for(const [u,v] of [[0.5,1.2],[0.5,7.2],[5.8,.4],[8.4,.4]]){const pos=P(u,v);path([{x:pos.x,y:pos.y-210},{x:pos.x,y:pos.y-110}],'#536e69',2);ellipse(pos.x,pos.y-107,24,11,'#f7bc6a');ellipse(pos.x,pos.y-98,35,8,'#fcefc37a')}
}
function floor(){
 const a=P(0,0),b=P(9,0),c=P(9,9),d=P(0,9);
 poly([a,b,c,d],'#fce9c8','#b6927c',4);
 // glossy tile reflections
 for(let u=0;u<9;u++)for(let v=0;v<9;v++){
  const k=P(u,v),l=P(u+1,v),m=P(u+1,v+1),n=P(u,v+1);
  poly([k,l,m,n],((u+v)%2===0?'#fff4dd':'#f6e2c7'),'#d9c7ae',.75);
  const p=P(u+.35,v+.5);poly([P(u+.1,v+.2),P(u+.2,v+.2),P(u+.24,v+.52),P(u+.14,v+.52)],'#ffffff60');
  path([P(u+.06,v+.07),P(u+.77,v+.07)],'#ffffff59',1.25);
 
 }
 path([a,b,c,d,a],'#ac9181',5);
 // front step sidewalk
 poly([P(9,0),P(9,9),{x:c.x,y:c.y+37},{x:b.x,y:b.y+37}],'#d7c2ab','#a98c75',2);
 poly([P(9,9),P(0,9),{x:d.x,y:d.y+37},{x:c.x,y:c.y+37}],'#cab39f','#a98c75',2);
}
function sticker(u,v,label,fill='#f67a73'){
 const p=P(u,v,1.43);round(p.x-48,p.y-18,96,27,8,fill,'#fff5cf');text(label,p.x,p.y-5,12,'#fffdf4');
}
function productUnit(u,v,z,kind,seed,scale=1){
 const palettes=itemPalette[kind]||itemPalette.snack,c=palettes[seed%palettes.length];
 const w=.24*scale,d=.24*scale,h=.37*scale;
 box(u,v,w,d,h,z,c,'#b17a73','#fff3c5','#94776f');
 // brand stripe and confetti logo
 const pt=P(u+w,v+d,z+h*.5);circle(pt.x-3,pt.y,2.3,'#ffffff');
 // Label, barcode and playful foil glint.
 const mark=P(u+w*.63,v+d+.002,z+h*.54);round(mark.x-3,mark.y-4,7,9,2,'#fff9e6e3');
 path([P(u+.02,v+d,z+h*.83),P(u+w-.02,v+d,z+h*.83)],'#ffffffb0',1.2);
 
}
function shelf(u,v,w,d,kind,qty,label){
 const full=Math.max(0,qty||0),layers=3;
 // cast shadow
 const sc=P(u+w*.55,v+d*.6);ellipse(sc.x,sc.y+12,w*31+17,d*18+12,'#6b625b35');
 box(u,v,w,d,.23,0,'#d8aa7b','#b77e69','#c99779','#866a65');
 for(let shelfLevel=0;shelfLevel<layers;shelfLevel++){
  const z=.3+shelfLevel*.5;
  box(u,v,w,d,.09,z,'#fff2d9','#81c4bd','#b0d7b9','#8cbab3');
  let total=Math.min(Math.ceil(full*.9),Math.round(w*4.0*d*4.7));let made=0;
  for(let du=.12;du<w-.09 && made<total;du+=.3)for(let dv=.1;dv<d-.05 && made<total;dv+=.25){productUnit(u+du,v+dv,z+.1,kind,made+shelfLevel*3,.94);made++}
  if(full===0){const p=P(u+w*.5,v+d*.6,z+.3);text('TRỐNG',p.x,p.y,12,'#d34b60')}
 }
 for(const [xx,yy] of [[u+.02,v+.02],[u+w-.04,v+.02],[u+.02,v+d-.04],[u+w-.04,v+d-.04]])box(xx,yy,.06,.06,1.78,0,'#dfc4a1','#986e5f','#e7c39b','#9e796a');
 const p=P(u+w*.45,v+d*.1,1.87);round(p.x-57,p.y-15,114,28,8,kind==='fruit'?'#54ae7c':'#ee776a','#fff9e4');text(label,p.x,p.y,13,'#fffef8');
}
function fridge(u,v,kind,qty,label){
 const w=1.85,d=.62;
 box(u,v,w,d,2.12,0,'#9fd3e5','#527b99','#d0e7f2','#547b98');
 // glass door face on east-facing visible facet
 for(let i=0;i<3;i++){
  const pa=P(u+.08+i*.57,v+d+.01,.27),pb=P(u+.59+i*.57,v+d+.01,.27),pc=P(u+.59+i*.57,v+d+.01,1.95),pd=P(u+.08+i*.57,v+d+.01,1.95);
  poly([pa,pb,pc,pd],'#7dcad9ab','#e2feff',2);
  poly([P(u+.11+i*.57,v+d+.016,.35),P(u+.17+i*.57,v+d+.016,.35),P(u+.49+i*.57,v+d+.016,1.8),P(u+.41+i*.57,v+d+.016,1.8)],'#ffffff23');
 
  // shelves of bright drinks
  for(let level=0;level<3;level++)for(let j=0;j<3;j++){
   const p=P(u+.18+i*.56+j*.13,v+d+.02,.43+level*.52);
   round(p.x-6,p.y-12,12,22,3,itemPalette[kind]?.[(i+j+level)%3]||'#cceafa','#ffffff99');
  }
  path([P(u+.44+i*.57,v+d+.015,.45),P(u+.44+i*.57,v+d+.015,1.82)],'#e5ffff82',3)
 }
 const head=P(u+w*.5,v+d*.16,2.26);round(head.x-68,head.y-16,136,29,8,'#426e8d','#edfcff');text(label,head.x,head.y-1,13,'#f6ffff');
}
function produce(u,v){
 ellipse(P(u+1,v+1).x,P(u+1,v+1).y+12,88,31,'#857a5644');
 box(u,v,2.1,1.6,.75,0,'#f4d097','#ae8b55','#f4ce9b','#bc8854');
 let k=0;for(let du=.16;du<2;du+=.29)for(let dv=.16;dv<1.4;dv+=.34){const pos=P(u+du,v+dv,.83);circle(pos.x,pos.y-5,7.8,['#f06a5d','#edac45','#73bb6d','#f2db64','#f47776'][k%5],'#d5ae79');circle(pos.x-2,pos.y-8,2.7,'#ffffffc2');if(k%4===0)path([{x:pos.x,y:pos.y-13},{x:pos.x+3,y:pos.y-17}],'#428853',2);k++}
 sticker(u+.62,v+.25,'RAU CỦ TƯƠI','#56a971');
}
function promoStand(u,v){
 const center=P(u+.65,v+.6);ellipse(center.x,center.y+10,53,15,'#735e5a45');
 box(u,v,1.35,1.12,.48,0,'#ffe5ad','#df767e','#fbba90','#b87370');
 for(let x=0;x<5;x++)for(let y=0;y<4;y++){
  const p=P(u+.17+x*.23,v+.16+y*.22,.59);
  circle(p.x,p.y,6.5,['#eb8976','#78bf97','#ffc96b','#9bb3e9'][x%4],'#ffffffae');
 }
 const pt=P(u+.65,v+.18,1.12);round(pt.x-50,pt.y-14,100,30,9,'#f16580','#fff4d4');text('SALE 50%',pt.x,pt.y+1,16,'#fff8da')
}
function cafe(u,v){
 box(u,v,1.02,.9,.55,0,'#fff1d2','#d58e76','#e9b38f','#a77570');
 box(u+.17,v+.12,.42,.33,.52,.56,'#a8ccde','#607e99','#e7e4d9','#617f8a');
 const pt=P(u+.5,v+.22,1.25);round(pt.x-45,pt.y-16,90,27,8,'#ab7b5c','#ffedbf');text('CÀ PHÊ',pt.x,pt.y-2,13,'#fff8e0');
}
function counter(u,v){
 const pos=P(u+1.5,v+1.05);ellipse(pos.x,pos.y+8,95,27,'#817e6666');
 box(u,v,2.75,1.24,.8,0,'#fff7e5','#df5b60','#fa9c8a','#ba6963');
 // glowing band on counter
 path([P(u,v+1.24,.25),P(u+2.75,v+1.24,.25)],'#ffecc1',8);
 box(u+.52,v+.12,.5,.29,.18,.84,'#485672','#2e4163','#9bd4e9','#31506d');
 const screen=P(u+.75,v+.35,1.15);round(screen.x-11,screen.y-23,25,25,3,'#dff9fe','#4c8894');text('₫',screen.x,screen.y-12,13,'#52b39e');
 box(u+1.45,v+.16,.62,.47,.1,.85,'#f4b87a','#cf8a69','#f5dbab','#a16c56');
 for(let j=0;j<4;j++){const p=P(u+1.55+j*.11,v+.27,.97);circle(p.x,p.y,4,['#ff977f','#e8db6a','#8dd3a5','#8ab6e2'][j])}
 const head=P(u+1.3,v+1.07,.9);round(head.x-81,head.y+6,160,24,9,'#e75762','#ffe8bc');text('🛒  THU NGÂN',head.x,head.y+18,15,'#fffef4');
}
function plant(u,v,size=1){
 box(u,v,.38*size,.38*size,.36*size,0,'#f1ac79','#b87762','#fac69e','#9b6f63');
 const p=P(u+.18*size,v+.18*size,.41*size);
 for(let i=0;i<7;i++){const a=(i/7)*Math.PI*2;ctx.save();ctx.translate(p.x,p.y);ctx.rotate(a);ellipse(0,-11*size,5*size,17*size,i%2?'#60ae7c':'#83d995');ctx.restore()}
 circle(p.x,p.y,4*size,'#f5e6a9');
}
function decor(s){
 plant(.5,7.6,.95);plant(8.55,.55,1.05);plant(8.3,7.8,.9);
 if(s.decor>0){for(const [u,v] of [[1.4,1.1],[4,8.5]])plant(u,v,.7)}
 if(s.decor>1){for(let i=0;i<6;i++){const pt=P(i+1,.6,2.65);circle(pt.x,pt.y,6,['#ffac82','#ffdb73','#7dd6c5'][i%3]);}}
}
let sceneObjects=[];
function drawObjects(state){
 sceneObjects=[];
 const d=(id,u,v,sort,draw,cap)=>sceneObjects.push({id,u,v,sort,draw,cap});
 d('fruit',1.05,2.2,3.9,()=>produce(1.05,2.2),'products');
 d('milk',4.2,.35,5.4,()=>fridge(4.2,.35,'milk',state.shelves.milk.front,'SỮA TƯƠI'),'stock');
 d('frozen',6.35,.35,7.8,()=>fridge(6.35,.35,'frozen',state.shelves.frozen.front,'ĐÔNG LẠNH'),'stock');
 d('drink',3.35,3.8,7.3,()=>shelf(3.35,3.8,2.0,.95,'drink',state.shelves.drink.front,'ĐỒ UỐNG'),'products');
 d('snack',5.55,3.0,8.6,()=>shelf(5.55,3.0,1.85,1.08,'snack',state.shelves.snack.front,'BÁNH KẸO'),'products');
 d('noodle',5.45,5.1,10.6,()=>shelf(5.45,5.1,1.85,1.08,'noodle',state.shelves.noodle.front,'MÌ GÓI'),'stock');
 d('checkout',2.65,6.0,9,()=>counter(2.65,6.0),'reports');
 d('coffee',1.2,5.1,6.3,()=>cafe(1.2,5.1),'products');
 d('sale',7.15,6.3,13.1,()=>promoStand(7.15,6.3),'marketing');
 if(state.storeGrade>=2)d('promo',2,4.15,6.2,()=>shelf(2,4.15,1.25,.8,'fruit',state.shelves.fruit.front,'SIÊU SALE'),'marketing');
 sceneObjects.sort((a,b)=>a.sort-b.sort);
 for(const obj of sceneObjects)obj.draw();
 decor(state);
}
function pcSceneryDetails(state){
  if(window.innerWidth<1080)return;
  // Grounded product aisle marking and soft reflected fixture light, baked into scene cache.
  for(const [u,v,sz] of [[1.25,7.45,.5],[7.5,7.4,.55],[8.3,2.2,.4]]){
    const p=P(u,v);ellipse(p.x,p.y,34*sz,10*sz,'#fdf6e44c');
  }
  const pay=P(3.2,7.25);
  text('CẢM ƠN QUÝ KHÁCH',pay.x,pay.y+25,12,'#d8b6a3');
  // Soft banner highlights emphasize hand-painted 2.5D geometry.
  for(let i=0;i<4;i++){const q=P(2.1+i*1.6,.15,2.65);circle(q.x,q.y,5,['#fbb884','#f8df89','#a0d7bd','#f1a6ad'][i]);}
}
function staticScene(state){wall();floor();pcSceneryDetails(state);drawObjects(state)}
const bg=document.createElement('canvas');bg.width=W;bg.height=H;
const bgctx=bg.getContext('2d',{alpha:false});let lastSig='';
function cache(state){
 const sig=[state.storeGrade,state.decor,...['drink','snack','milk','fruit','noodle','frozen'].map(x=>state.shelves[x].front)].join(':');
 if(sig===lastSig)return;
 lastSig=sig;ctx=bgctx;ctx.setTransform(1,0,0,1,0,0);
 ctx.clearRect(0,0,W,H);staticScene(state);
 ctx=viewCtx;
}
const customers=[];let particle=[];const staff=[{kind:'an',u:3.15,v:5.8,move:.3},{kind:'binh',u:5.6,v:2.5,move:1.2},{kind:'linh',u:2.25,v:2.8,move:2.4}];
const routes={
 ok:[[.85,8.65],[2,7.65],[4,5.4],[5.7,4.65],[3.25,7.35],[.85,8.65]],
 miss:[[.85,8.65],[2,7.75],[5.4,4.3],[.85,8.65]]
};
function spawnCustomer(ok){if(customers.length>6)customers.shift();const q=customers.length%3;customers.push({kind:'customer_'+['a','b','c'][q],ok,t:0,route:ok?routes.ok:routes.miss,seed:Math.random()*9});if(ok){particle.push({u:3.1,v:6.4,txt:'+₫',ttl:1.2,t:0});}}
function positionAlong(c){const r=c.route,t=Math.min(r.length-1.001,c.t/2.4),n=Math.floor(t),p=t-n;const a=r[n],b=r[n+1];return {u:a[0]+(b[0]-a[0])*p,v:a[1]+(b[1]-a[1])*p,walking:p>.02&&p<.97}}
function actor(ch,u,v,time,walking,flip=false,scale=1,mood='idle'){
 const p=P(u,v,0);const bob=walking?Math.sin(time*.015+u)*3.3:Math.sin(time*.002+u)*1.2;
 ellipse(p.x,p.y+2,24*scale,8*scale,'#2d5b5655');ellipse(p.x-3,p.y+4,16*scale,5*scale,'#254c5040');
 let key='art/'+ch+'_'+(mood==='work'?'work':walking?'wave':'idle')+'_happy';const im=imgs[key]||imgs['art/'+ch+'_idle_happy'];
 const h=84*scale,w=78*scale;
 if(im&&im.complete&&im.naturalWidth){ctx.save();ctx.translate(p.x,p.y-h*.84+bob);if(flip)ctx.scale(-1,1);ctx.drawImage(im,-w/2,0,w,h);ctx.restore()}
 else{circle(p.x,p.y-55*scale,23*scale,'#ffcaa5','#755a61');circle(p.x-8*scale,p.y-58*scale,3*scale,'#384f66');circle(p.x+8*scale,p.y-58*scale,3*scale,'#384f66');}
}
function bubble(txt,x,y){round(x-34,y-60,70,27,10,'#fffcf0','#e9bba3');text(txt,x,y-46,14,'#a76063')}
function shader(state,time){
 // center light with minimal overdraw
 if(state.minute>=1110){ctx.fillStyle='#17295835';ctx.fillRect(0,0,W,H)}
 if(state.day%5===0){ctx.fillStyle='#b9d4f313';ctx.fillRect(0,0,W,H)}
 // animated reflections, gently moving illumination; respect reduced motion
 if(!state.reduceMotion){for(let i=0;i<8;i++){const x=215+((i*139)%780),y=160+((i*73)%385);const a=.3+.34*Math.sin(time*.0013+i*4);ctx.globalAlpha=a;circle(x,y,2.5,'#fff6d9');ctx.globalAlpha=1}}
}
let transform={scale:1,tx:0,ty:0},cameraX=0,zoomFactor=1,drag=null,previous=0,fps=30,duration=0,frames=0;
function syncSize(){const rect=canvas.getBoundingClientRect();const qual=window.ChibiV100?.getState?.()?.quality||'balanced';const dpr=Math.min(qual==='high'?2.4:qual==='eco'?1.25:2,devicePixelRatio||1);const cw=Math.max(1,Math.round(rect.width*dpr)),ch=Math.max(1,Math.round(rect.height*dpr));if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch;}const ratio=rect.width/Math.max(1,rect.height);const scale=(ratio>1.8?Math.min(rect.width/W,rect.height/H)*1.12:Math.max(rect.width/W,Math.min(rect.height/H,rect.width/660)))*zoomFactor;const shift=Math.max(0,(W*scale-rect.width)/2);const maxPan=Math.max(0,W*scale-rect.width);cameraX=Math.max(-maxPan/2,Math.min(maxPan/2,cameraX));transform={scale,tx:(rect.width-W*scale)/2+cameraX,ty:(rect.height-H*scale)/2};viewCtx.setTransform(dpr*scale,0,0,dpr*scale,dpr*transform.tx,dpr*transform.ty);return dpr}
function drawFrame(t){if(document.hidden){requestAnimationFrame(drawFrame);return}const s=window.ChibiV100?.getState?.();if(!s){requestAnimationFrame(drawFrame);return}const limit=(window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches||s.reduceMotion)?12:s.quality==='eco'?24:s.quality==='high'?(innerWidth>=1080?60:45):30;
 if(t-previous<1000/limit-1){requestAnimationFrame(drawFrame);return}const delta=previous?Math.min(.07,(t-previous)/1000):.033;previous=t;duration+=delta;frames++;
 for(const c of customers)c.t+=delta*1.18;
 for(let i=customers.length-1;i>=0;i--)if(customers[i].t>2.4*(customers[i].route.length-1))customers.splice(i,1);
 for(const pt of particle)pt.t+=delta;particle=particle.filter(p=>p.t<p.ttl);
 syncSize();ctx=viewCtx;ctx.save();
 // A pastel backdrop fills the whole viewport on narrow phones (never black side bands).
 ctx.setTransform(1,0,0,1,0,0);
 const wash=ctx.createLinearGradient(0,0,0,canvas.height);wash.addColorStop(0,'#b5e7d6');wash.addColorStop(.65,'#e4f6d8');wash.addColorStop(1,'#f8eac8');
 ctx.fillStyle=wash;ctx.fillRect(0,0,canvas.width,canvas.height);
 const qual=window.ChibiV100?.getState?.()?.quality||'balanced';const dpr=Math.min(qual==='high'?2.4:qual==='eco'?1.25:2,devicePixelRatio||1);
 ctx.setTransform(dpr*transform.scale,0,0,dpr*transform.scale,dpr*transform.tx,dpr*transform.ty);
 cache(s);ctx.drawImage(bg,0,0);
 const secs=s.reduceMotion?0:t;
 actor('an',2.9,6.15,secs,false,false,1.04,'work');
 for(let i=0;i<Math.min(s.staff-1,staff.length-1);i++){const ch=staff[i+1];actor(ch.kind,ch.u+.3*Math.sin(t*.0003+i),ch.v+.18*Math.cos(t*.0005+i),secs,true,i%2===0,1.0,'work')}
 for(const c of customers){const at=positionAlong(c);actor(c.kind,at.u,at.v,secs+ c.seed*1000,at.walking,false,1.08);if(c.t>3&&c.t<3.7) {const p=P(at.u,at.v,0);bubble(c.ok?'🛒':'❔',p.x,p.y-61)}}
 for(const pt of particle){const p=P(pt.u,pt.v,1.2+pt.t*1.3);ctx.globalAlpha=Math.max(0,1-pt.t/pt.ttl);text(pt.txt,p.x,p.y,22,'#20a277','center','#ffffff');ctx.globalAlpha=1}
 shader(s,t);ctx.restore();requestAnimationFrame(drawFrame)}
canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,start:cameraX,moved:false};canvas.setPointerCapture?.(e.pointerId)});
canvas.addEventListener('pointermove',e=>{if(!drag)return;let dx=e.clientX-drag.x;if(Math.abs(dx)>10)drag.moved=true;const w=canvas.getBoundingClientRect().width;const max=Math.max(0,W*transform.scale-w)/2;cameraX=Math.max(-max,Math.min(max,drag.start+dx))});
canvas.addEventListener('pointerup',e=>{if(!drag)return;const moved=drag.moved;drag=null;if(moved)return;const bounds=canvas.getBoundingClientRect();const x=(e.clientX-bounds.left-transform.tx)/transform.scale,y=(e.clientY-bounds.top-transform.ty)/transform.scale;let nearest=null,d=95;
 for(const obj of sceneObjects){const p=P(obj.u+.7,obj.v+.6,0),dd=Math.hypot(p.x-x,(p.y-40)-y);if(dd<d){d=dd;nearest=obj}}
 if(nearest){window.ChibiV100?.openPanel(nearest.cap);particle.push({u:nearest.u,v:nearest.v,txt:'✨',t:0,ttl:.8})}
});
function zoom(delta){zoomFactor=Math.max(.7,Math.min(1.75,zoomFactor+delta));syncSize();return zoomFactor}
function pan(amount){const w=canvas.getBoundingClientRect().width;const max=Math.max(0,W*transform.scale-w)/2;cameraX=Math.max(-max,Math.min(max,cameraX+amount));return cameraX}
canvas.addEventListener('wheel',e=>{if(innerWidth<1080)return;e.preventDefault();zoom(e.deltaY<0?.09:-.09)},{passive:false});
const world=document.getElementById('world');world.classList.add('isometricScene');
requestAnimationFrame(drawFrame);
window.Store2D5={spawnCustomer,zoom,pan,stats:()=>({mode:'Canvas 2.5D',fpsLimit:(window.ChibiV100?.getState?.()?.quality==='high'?(innerWidth>=1080?60:45):30),activeCustomers:customers.length,fixtures:sceneObjects.length}),project:P};
})();
