/* Cửa Hàng V101 PC · offline-first versioned cache */
const CACHE='cuahang-pc-v101-25d-v1';
const CORE=["./index.html", "./style.css", "./game.js", "./scene25.js", "./desktop.js", "./desktop.css", "./manifest.webmanifest", "./assets/merch/drink.png", "./assets/merch/fruit.png", "./assets/merch/noodle.png", "./assets/merch/milk.png", "./assets/merch/frozen.png", "./assets/merch/snack.png", "./assets/ui/icon192.png", "./assets/ui/icon512.png", "./assets/art/linh_wave_happy.png", "./assets/art/customer_b_idle_happy.png", "./assets/art/an_wave_happy.png", "./assets/art/customer_c_work_happy.png", "./assets/art/minh_work_happy.png", "./assets/art/minh_idle_happy.png", "./assets/art/customer_c_wave_happy.png", "./assets/art/minh_scan_happy.png", "./assets/art/customer_a_work_happy.png", "./assets/art/linh_work_happy.png", "./assets/art/binh_work_happy.png", "./assets/art/minh_wave_happy.png", "./assets/art/customer_b_wave_happy.png", "./assets/art/linh_scan_happy.png", "./assets/art/customer_a_idle_happy.png", "./assets/art/binh_wave_happy.png", "./assets/art/customer_a_wave_happy.png", "./assets/art/customer_b_work_happy.png", "./assets/art/customer_c_idle_happy.png", "./assets/art/customer_a_scan_happy.png", "./assets/art/linh_idle_happy.png", "./assets/art/binh_scan_happy.png", "./assets/art/customer_b_scan_happy.png", "./assets/art/binh_idle_happy.png", "./assets/art/an_scan_happy.png", "./assets/art/an_idle_happy.png", "./assets/art/customer_c_scan_happy.png", "./assets/art/an_work_happy.png", "./assets/scene/title25.webp", "./assets/scene/title.webp", "./assets/scene/store.webp"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('cuahang-pc-v101-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{
  if(res.ok){const copy=res.clone();caches.open(CACHE).then(cache=>cache.put(req,copy));}
  return res;
 }).catch(()=>cached||Response.error())));
});
